from coloring_main import run_coloring_grover
from utils import get_cost

from graph_examples import get_ibm_graph


def get_hackathon_circuit():
    graph = get_ibm_graph()
    qc = run_coloring_grover(graph, 5)
    return qc


def get_ibm_cost():
    graph = get_ibm_graph()
    qc = run_coloring_grover(graph, 5)

    cost = get_cost(qc)

    total_qubits = graph.get_ancilla_size_needed() + len(graph.vertices) * graph.color_bit_length

    print(f"Number of qubits needed: {total_qubits}")
    print(f"Cost was: {cost}")


if __name__ == '__main__':
    # reg = QuantumRegister(2)
    # qc = QuantumCircuit(reg)
    # qc.crz(pi, 0, 1)
    # cost = get_cost(qc)
    # print(f"Cost was: {cost}")
    get_ibm_cost()

